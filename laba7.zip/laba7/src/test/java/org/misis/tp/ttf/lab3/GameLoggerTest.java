package org.misis.tp.ttf.lab3;

import org.junit.Test;
import org.junit.jupiter.api.Assertions;

public class GameLoggerTest {
    //Проверяется, что метод getInstance возвращает один и тот же объект (паттерн Singleton):
    @Test
    public void getInstanceTest() {
        GameLogger firstInstance = GameLogger.getInstance();
        GameLogger secondInstance = GameLogger.getInstance();

        int firstInstanceIdent = System.identityHashCode(firstInstance);
        int secondInstanceIdent = System.identityHashCode(secondInstance);

        Assertions.assertEquals(firstInstanceIdent, secondInstanceIdent);
    }

}
