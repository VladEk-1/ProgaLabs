package org.misis.tp.ttf.lab5.chain;

import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.mockito.Mockito;

import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class DamageHandlerTest {
// важно проверить как то, что правильно работает передача вызовов в абстрактном хендлере,
// так и то что корректно отрабатывает логика конкретных хендлеров и их передача запроса по цепочке
    @Test
    @DisplayName("Тестирует базовую структуру абстрактного обработчика")
    public void AbstractDamageHandlerTest() {
        AbstractDamageHandler testAbstractDamageHandler = new AbstractDamageHandler();
        int testDamage = 0;

        // тестирует завершение обработки если текущий обработчик - последний
        int actualDamage = testAbstractDamageHandler.handle(testDamage);

        Assertions.assertEquals(testDamage, actualDamage);

        // тестирует передачу обработки следующему обработчику
        AbstractDamageHandler testNextAbstractDamageHandlerMock = Mockito.mock(AbstractDamageHandler.class);
        int testHandledDamage = 10;
        when(testNextAbstractDamageHandlerMock.handle(testDamage)).thenReturn(testHandledDamage);

        testAbstractDamageHandler.setNext(testNextAbstractDamageHandlerMock);
        actualDamage = testAbstractDamageHandler.handle(testDamage);

        Assertions.assertEquals(testHandledDamage, actualDamage);
        verify(testNextAbstractDamageHandlerMock, times(1)).handle(testDamage);
    }

    @Test
    @DisplayName("Тестирует обнуление урона обработчиком неуязвимости")
    public void InvulnerabilityDamageHandlerTest() {
        InvulnerabilityDamageHandler invulnerabilityDamageHandler = new InvulnerabilityDamageHandler();
        int testDamage = 100;
        int zero = 0;

        int actualDamage = invulnerabilityDamageHandler.handle(testDamage);

        Assertions.assertEquals(zero, actualDamage);

        // тестирует передачу урона следующему хендлеру
        // передачи быть не должно - хендлер должен вызывать короткое замыкание цепочки
        AbstractDamageHandler mockHandler = Mockito.mock(AbstractDamageHandler.class);
        invulnerabilityDamageHandler.setNext(mockHandler);

        actualDamage = invulnerabilityDamageHandler.handle(testDamage);

        Assertions.assertEquals(zero, actualDamage);
        verify(mockHandler, never()).handle(anyInt());
    }

    @Test
    public void BarrierDamageHandlerTest() {
        int testBarrierHealth = 100;
        BarrierDamageHandler barrierDamageHandler = new BarrierDamageHandler(testBarrierHealth);

        // наносит урон равный двойному здоровью щита - ожидаем что часть урона останется
        int doubleTestBarrierHealth = testBarrierHealth * 2;
        int halfOfDealtDamage = doubleTestBarrierHealth - testBarrierHealth;

        int actualDamage = barrierDamageHandler.handle(doubleTestBarrierHealth);

        Assertions.assertEquals(halfOfDealtDamage, actualDamage);

        // тестирует передачу урона следующему хендлеру
        // следующему хендлеру должна уйти только часть урона
        barrierDamageHandler = new BarrierDamageHandler(testBarrierHealth);
        AbstractDamageHandler mockHandler = Mockito.mock(AbstractDamageHandler.class);
        barrierDamageHandler.setNext(mockHandler);
        when(mockHandler.handle(halfOfDealtDamage)).thenReturn(halfOfDealtDamage);

        actualDamage = barrierDamageHandler.handle(doubleTestBarrierHealth);

        Assertions.assertEquals(halfOfDealtDamage, actualDamage);
        verify(mockHandler, times(1)).handle(halfOfDealtDamage);

        // наносит урон равный половине щита - ожидаем что щит поглотит весь урон
        // два раза, после чего закончится и урон станет проходить полностью
        int halfOfTestBarrierHealth = testBarrierHealth / 2;
        int zero = 0;
        barrierDamageHandler = new BarrierDamageHandler(testBarrierHealth);

        int actualDamageFirst = barrierDamageHandler.handle(halfOfTestBarrierHealth);
        int actualDamageSecond = barrierDamageHandler.handle(halfOfTestBarrierHealth);
        int actualDamageThird = barrierDamageHandler.handle(halfOfTestBarrierHealth);

        Assertions.assertEquals(zero, actualDamageFirst);
        Assertions.assertEquals(zero, actualDamageSecond);
        Assertions.assertEquals(halfOfTestBarrierHealth, actualDamageThird);
    }

    @Test
    public void BuffDebuffDamageHandlerTest() {
        int testDamage = 100;

        // тестирует бафф (уменьшение урона)
        float testBuffMultiplier = 0.3f;
        BuffDebuffDamageHandler buffDamageHandler = new BuffDebuffDamageHandler(testBuffMultiplier);
        int expectedBuffDebuffHandledDamage = Math.round(testDamage * testBuffMultiplier);

        int actualUnderBuffDamage = buffDamageHandler.handle(testDamage);

        Assertions.assertEquals(expectedBuffDebuffHandledDamage, actualUnderBuffDamage);

        // тестирует дебафф (увеличение урона)
        float testDebuffMultiplier = 1.3f;
        BuffDebuffDamageHandler debuffDamageHandler = new BuffDebuffDamageHandler(testDebuffMultiplier);
        expectedBuffDebuffHandledDamage = Math.round(testDamage * testDebuffMultiplier);

        int actualUnderDebuffDamage = debuffDamageHandler.handle(testDamage);

        Assertions.assertEquals(expectedBuffDebuffHandledDamage, actualUnderDebuffDamage);

        // тестирует передачу урона следующему хендлеру
        // следующему хендлеру должен уйти измененный урон
        AbstractDamageHandler mockHandler = Mockito.mock(AbstractDamageHandler.class);
        debuffDamageHandler.setNext(mockHandler);
        when(mockHandler.handle(expectedBuffDebuffHandledDamage)).thenReturn(testDamage);

        int actualDamage = debuffDamageHandler.handle(testDamage);

        Assertions.assertEquals(testDamage, actualDamage);
        verify(mockHandler, times(1)).handle(expectedBuffDebuffHandledDamage);
    }

}
