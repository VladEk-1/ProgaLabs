package org.misis.tp.ttf.lab7;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.misis.tp.ttf.lab7.entity.Order;
import org.misis.tp.ttf.lab7.entity.User;

import java.util.Objects;
import java.util.Properties;

import static org.hibernate.cfg.JdbcSettings.DIALECT;
import static org.hibernate.cfg.JdbcSettings.JAKARTA_JDBC_DRIVER;
import static org.hibernate.cfg.JdbcSettings.JAKARTA_JDBC_PASSWORD;
import static org.hibernate.cfg.JdbcSettings.JAKARTA_JDBC_URL;
import static org.hibernate.cfg.JdbcSettings.JAKARTA_JDBC_USER;
import static org.hibernate.cfg.JdbcSettings.SHOW_SQL;

// обратите внимание - паттерн синглтон!
public class SessionFactorySingleton {

    private static SessionFactory INSTANCE;

    public static SessionFactory getInstance() {
        if (Objects.isNull(INSTANCE)) {
            INSTANCE = initInstance();
        }

        return INSTANCE;
    }

    private static SessionFactory initInstance() {
        Properties properties = new Properties();
        // в качестве БД будем использовать H2 - поэтому и драйверы соответствующие
        properties.put(DIALECT, "org.hibernate.dialect.H2Dialect");
        properties.put(JAKARTA_JDBC_DRIVER, "org.h2.Driver");
        // данные для подключения
        properties.put(JAKARTA_JDBC_USER, "root");
        properties.put(JAKARTA_JDBC_PASSWORD, "password");
        // урл для подключения к БД через JDBC драйвер -
        // в нашем случае это просто обращение к БД в памяти (спасибо H2, очень удобно)
        properties.put(JAKARTA_JDBC_URL, "jdbc:h2:mem:test");
        // автоматически создает таблички в базе на основе сущностей (и дропает их при выходе из программы)
        properties.put("hibernate.hbm2ddl.auto", "create-drop");
        // включает логирование генерируемых SQL запросов
        properties.put(SHOW_SQL, "true");

        // обратите внимание - паттерн строитель!
        return new Configuration()
                .addProperties(properties)
                .addAnnotatedClass(User.class)
                .addAnnotatedClass(Order.class)
                // так можно привязать сразу все сущности из пакета,
                // не делаем так, чтобы лаба не ломалась при неправильной структуре пакетов :)
                //.addPackage("org.misis.tp.ttf.lab7.entity")
                .buildSessionFactory();
    }

}