package org.misis.tp.ttf.lab7;

import org.hibernate.Session;
import org.misis.tp.ttf.lab7.entity.Order;

import java.util.List;

public class OrderService {

    public List<Order> findAll() {
        try (Session session = SessionFactorySingleton.getInstance().openSession()) {
            session.beginTransaction();

            List<Order> orders = session.createQuery("FROM Order", Order.class).getResultList();

            session.getTransaction().commit();
            return orders;
        }
    }

}
