package org.misis.tp.ttf.lab7.entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import java.util.LinkedHashSet;
import java.util.Set;

import static jakarta.persistence.FetchType.LAZY;

@Entity
@Table(name = "users")
public class User extends BaseEntity {

    @Column(unique = true)
    private String username;

    // обратите внимание, для реализации ленивой загрузки связей Hibernate использует паттерн прокси!
    // а еще тут мы говорим, что хотим переносить на связи операции над пользователем, а также
    // удалять заказы без пользователей,
    // так мы сможем работать с заказами через пользователя, а не через отдельный CRUD сервис
    @OneToMany(fetch = LAZY, mappedBy = "user", cascade = {CascadeType.ALL}, orphanRemoval = true)
    private Set<Order> orders = new LinkedHashSet<>();

    public Set<Order> getOrders() {
        return orders;
    }

    public void addOrder(Order order) {
        orders.add(order);
        order.setUser(this);
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

}