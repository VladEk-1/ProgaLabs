package org.misis.tp.ttf.lab7;

import org.hibernate.Session;
import org.misis.tp.ttf.lab7.entity.User;

import java.util.List;

public class UserService {

    public User createUser(String username) {
        //нужно чтобы закрывать  автоматически сессии при выходе из метода
        try (Session session = SessionFactorySingleton.getInstance().openSession()) {
            session.beginTransaction();

            User user = new User();
            user.setUsername(username);

            session.persist(user);

            session.getTransaction().commit();
            return user;
        }
    }

    public User findUserById(Long id, boolean withOrders) {
        try (Session session = SessionFactorySingleton.getInstance().openSession()) {
            session.beginTransaction();

            User user = withOrders ?
                    // если нам нужны связи - используем JOIN FETCH, альтернативно можно воспользоваться EntityGraph
                    session
                            .createQuery("FROM User JOIN FETCH User.orders WHERE User.id = ?1", User.class)
                            .setParameter(1, id)
                            .getSingleResult()
                    :
                    session.get(User.class, id);

            session.getTransaction().commit();
            return user;
        }
    }

    public List<User> findAll(boolean withOrders) {
        try (Session session = SessionFactorySingleton.getInstance().openSession()) {
            session.beginTransaction();

            List<User> users = withOrders ?
                    session.createQuery("FROM User JOIN FETCH orders", User.class).getResultList()
                    :
                    session.createQuery("FROM User", User.class).getResultList();

            session.getTransaction().commit();
            return users;
        }
    }

    public User updateUser(User user) {
        try (Session session = SessionFactorySingleton.getInstance().openSession()) {
            session.beginTransaction();

            user = session.merge(user);

            session.getTransaction().commit();
            return user;
        }
    }

    public void deleteUser(Long id) {
        try (Session session = SessionFactorySingleton.getInstance().openSession()) {
            session.beginTransaction();
            session.remove(session.getReference(User.class, id));
            session.getTransaction().commit();
        }
    }

}