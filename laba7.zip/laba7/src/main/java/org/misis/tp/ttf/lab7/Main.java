package org.misis.tp.ttf.lab7;

import org.misis.tp.ttf.lab7.entity.Order;
import org.misis.tp.ttf.lab7.entity.User;

import java.util.Collection;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        UserService userService = new UserService();
        OrderService orderService = new OrderService();

        User babuleh = userService.createUser("babuleh");
        User secondBabuleh = userService.createUser("second_babuleh");

        Order babulehOrderDiamonds = new Order();
        babulehOrderDiamonds.setProductName("Diamonds");
        babulehOrderDiamonds.setProductCount(100L);

        Order babulehOrderGold = new Order();
        babulehOrderGold.setProductName("Gold");
        babulehOrderGold.setProductCount(2000L);

        babuleh.addOrder(babulehOrderDiamonds);
        babuleh.addOrder(babulehOrderGold);

        babuleh = userService.updateUser(babuleh);

        // достаем всех пользователей и выводим информацию об их заказах
        // делаем это одним запросом, подтягивая и пользователей, и заказы
        List<User> users = userService.findAll(true);

        for (User user : users) {
            System.out.printf("Пользователь: {id: '%s'; username: '%s'}%n",
                    user.getId(), user.getUsername());

            printOrdersInfo(user.getOrders());
        }

        // удаляем пользователя и проверяем, что удалились заказы
        userService.deleteUser(babuleh.getId());
        List<Order> orders = orderService.findAll();
        if (orders.isEmpty())
            System.out.println("В сервисе нет заказов!");
        printOrdersInfo(orders);
    }

    private static void printOrdersInfo(Collection<Order> orders) {
        for (Order order : orders) {
            System.out.printf("Заказ: {id: '%s'; productName: '%s'; productCount: '%s'}%n",
                    order.getId(), order.getProductName(), order.getProductCount());
        }
    }

}